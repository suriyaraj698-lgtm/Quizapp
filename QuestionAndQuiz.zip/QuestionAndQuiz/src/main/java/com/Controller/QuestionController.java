package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.DAO.QuestionRepository;
import com.Entity.Question;
import com.Service.QuestionService;

@RestController
@RequestMapping("/question")
public class QuestionController {
	@Autowired
	QuestionService service;
	@Autowired
	QuestionRepository dao;
	public String getquestion() {
		return "Hi i m surya";
	}

	@PostMapping
	public String saveAll(@RequestBody List<Question> q) {
		List<Question> list = dao.saveAll(q);
		if(list!=null)
		return "success";
		return "not";
	}
	
	@GetMapping("/allQuestions")
	public List<com.Entity.Question> getallquestions(){
		return service.getallquestions();
	}
	@GetMapping("/getcategory")
	public List<Question>getcategory(String category){
		return service.getcategory(category);
	}
	@PostMapping("/add")
	public String addQuestion(@RequestBody Question question) {
		System.out.println(question.getOption1());
		service.addQuestion(question) ;
		return "Sucess";
	}
	@PutMapping("/update")
	public Question updateQuestion(@RequestBody Question question) {
	    return service.updateQuestion(question);
	}
	@DeleteMapping("/delete")
	public String deleteByTitle(@RequestParam String title) {
	    return service.deleteByTitle(title);
	}
	
}