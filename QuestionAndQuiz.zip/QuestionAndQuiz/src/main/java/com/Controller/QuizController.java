package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Dto.QuestionWrapper;
import com.Dto.Response;
import com.Dto.ScoreResponse;
import com.Entity.Question;
import com.Entity.Quiz;
import com.Service.QuizService;

@RestController
@RequestMapping("/quiz")
public class QuizController {

    @Autowired
    
    private QuizService service;

    // ✅ CREATE QUIZ
    @PostMapping("/create")
    public Quiz createQuiz(@RequestParam String title,
                           @RequestParam String category,
                           @RequestParam int numQ) {

        return service.createQuiz(title, category, numQ);
    }
    

    // ✅ GET QUIZ BY TITLE (WITHOUT ANSWERS)
    @GetMapping("/get/title/{title}")
    public List<QuestionWrapper> getQuizByTitle(@PathVariable String title) {
        return service.getQuizByTitle(title);
    }

    // ✅ GET QUIZ BY ID (WITH ANSWERS)
    @GetMapping("/get/id/{id}")
    public List<Question> getQuizById(@PathVariable int id) {
        return service.getQuiz(id);
    }

    // ✅ SUBMIT QUIZ & GET SCORE (UPDATED)
     @PostMapping("/submit/{title}")
    public ScoreResponse submitQuiz(@PathVariable String title,
                                   @RequestBody List<Response> responses) {

        return service.calculateScore(title, responses);
    }
}