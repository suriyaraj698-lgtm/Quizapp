package com.DAO;

import java.util.List;
import java.util.Locale.Category;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Entity.Question;
@Repository
public interface QuestionRepository extends JpaRepository<Question, Integer> {
	List<Question> findByCategory(String category);
	@Query(value = "SELECT * FROM question WHERE category = :category ORDER BY RANDOM() LIMIT :num", nativeQuery = true)
	List<Question> findRandomQuestions(String category, int num);
	Question findByQuestiontitle(String questiontitle);
	
}
