package com.DAO;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Entity.Question;
import com.Entity.Quiz;

public interface QuizRepository extends JpaRepository<Quiz, Integer> {
	 Quiz findByTitle(String title);

}


