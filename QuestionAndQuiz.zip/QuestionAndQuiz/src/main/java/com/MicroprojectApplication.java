package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroprojectApplication.class, args);
	}

}

//{
//    
//  "questiontitle": "What is java8?",
//  "option1": "Programming Language",
//  "option2": "Advanced java",
//  "option3": "Operating System",
//  "option4": "Browser",
//  "rightAnswer": "Advanced java",
//  "difficultylevel": "Easy",
//  "category": "Programming"
//}
//
//
//
