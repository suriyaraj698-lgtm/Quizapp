package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.DAO.QuestionRepository;
import com.Entity.Question;
@Service
public class QuestionService {
	@Autowired
	QuestionRepository repo;
	



	public List<Question> getallquestions(){
		return repo.findAll();
	}
	

public List<Question>getcategory(@PathVariable String category){
	return repo.findByCategory(category);
}
	
	public String addQuestion( Question  question) {
		System.out.println(question.getOption1());
		repo.save(question);
		return "success";
	}

	public Question updateQuestion(Question newQuestion) {

	    Question existing = repo.findByQuestiontitle(newQuestion.getQuestiontitle());

	    if (existing == null) {
	        throw new RuntimeException("Question not found");
	    }

	    existing.setOption1(newQuestion.getOption1());
	    existing.setOption2(newQuestion.getOption2());
	    existing.setOption3(newQuestion.getOption3());
	    existing.setOption4(newQuestion.getOption4());
	    existing.setRightAnswers(newQuestion.getRightAnswer());
	    existing.setDifficultylevel(newQuestion.getDifficultylevel());
	    existing.setCategory(newQuestion.getCategory());

	    return repo.save(existing);
	}
	public String deleteByTitle(String title) {

	    Question question = repo.findByQuestiontitle(title);

	    if (question == null) {
	        throw new RuntimeException("Question not found");
	    }

	    repo.delete(question);

	    return "Question deleted successfully";
	}
	}
