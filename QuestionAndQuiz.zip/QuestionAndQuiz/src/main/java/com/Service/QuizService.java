package com.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.QuestionRepository;
import com.DAO.QuizRepository;
import com.Dto.QuestionWrapper;
import com.Dto.Response;
import com.Dto.ScoreResponse;
import com.Entity.Question;
import com.Entity.Quiz;

@Service
public class QuizService {

    @Autowired
    private QuizRepository quizRepo;

    @Autowired
    private QuestionRepository questionRepo;

    // ✅ CREATE QUIZ
    public Quiz createQuiz(String title, String category, int numQ) {

        if (quizRepo.findByTitle(title) != null) {
            throw new RuntimeException("Quiz already exists with title: " + title);
        }

        List<Question> questions = questionRepo.findRandomQuestions(category, numQ);

        if (questions.isEmpty()) {
            throw new RuntimeException("No questions found for category: " + category);
        }

        Quiz quiz = new Quiz();
        quiz.setTitle(title);
        quiz.setCategory(category);
        quiz.setNumQuestions(numQ);
        quiz.setQuestions(questions);

        return quizRepo.save(quiz);
    }

    // ✅ GET QUIZ BY ID (WITH ANSWERS)
    public List<Question> getQuiz(int id) {

        Optional<Quiz> quiz = quizRepo.findById(id);

        if (quiz.isPresent()) {
            return quiz.get().getQuestions();
        } else {
            throw new RuntimeException("Quiz not found with id: " + id);
        }
    }

    // ✅ GET QUIZ BY TITLE (WITHOUT ANSWERS)
    public List<QuestionWrapper> getQuizByTitle(String title) {

        Quiz quiz = quizRepo.findByTitle(title);

        if (quiz == null) {
            throw new RuntimeException("Quiz not found");
        }

        List<QuestionWrapper> wrappers = new ArrayList<>();

        for (Question q : quiz.getQuestions()) {

            QuestionWrapper w = new QuestionWrapper();

            w.setId(q.getId());
            w.setQuestiontitle(q.getQuestiontitle());
            w.setOption1(q.getOption1());
            w.setOption2(q.getOption2());
            w.setOption3(q.getOption3());
            w.setOption4(q.getOption4());

            wrappers.add(w);
        }

        return wrappers;
    }

    // ✅ CALCULATE SCORE
    public ScoreResponse calculateScore(String title, List<Response> responses) {

        Quiz quiz = quizRepo.findByTitle(title);

        if (quiz == null) {
            throw new RuntimeException("Quiz not found");
        }

        List<Question> questions = quiz.getQuestions();

        int score = 0;

        for (Response res : responses) {

            for (Question q : questions) {

                if (q.getId().equals(res.getId())) {

                    if (q.getRightAnswer().equalsIgnoreCase(res.getResponse())) {
                        score++;
                    }

                    break; // stop searching once matched
                }
            }
        }

        ScoreResponse result = new ScoreResponse();
        result.setScore(score);
        result.setTotal(questions.size());

        return result;
    }
}
